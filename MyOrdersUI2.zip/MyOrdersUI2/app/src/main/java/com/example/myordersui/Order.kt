package com.example.myordersui

data class Order(
    val vehicle: String,
    val orderId: String,
    val pickup: String,
    val drop: String,
    val price: String
)