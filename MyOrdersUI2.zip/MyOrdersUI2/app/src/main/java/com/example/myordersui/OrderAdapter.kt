package com.example.myordersui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class OrderAdapter(private val orderList: List<Order>) :
    RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {

    class OrderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val vehicle: TextView = itemView.findViewById(R.id.txtVehicle)
        val order: TextView = itemView.findViewById(R.id.txtOrder)
        val pickup: TextView = itemView.findViewById(R.id.txtPickup)
        val drop: TextView = itemView.findViewById(R.id.txtDrop)
        val price: TextView = itemView.findViewById(R.id.txtPrice)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_order, parent, false)

        return OrderViewHolder(view)
    }

    override fun getItemCount(): Int {
        return orderList.size
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {

        val currentItem = orderList[position]

        holder.vehicle.text = currentItem.vehicle
        holder.order.text = currentItem.orderId
        holder.pickup.text = currentItem.pickup
        holder.drop.text = currentItem.drop
        holder.price.text = currentItem.price
    }
}